# YouTube Video Summarizer

A powerful web-based application that transforms YouTube video content into structured, readable formats using AI-powered analysis.

## 🚀 Features

- **📹 Video Processing**: Accept any YouTube video URL and extract its transcript
- **🤖 AI-Powered Analysis**: Uses Large Language Models to generate multiple content formats
- **📝 Multiple Output Formats**:
  - Executive Summary
  - Detailed Article
  - Key Points extraction
  - Q&A pairs
  - Timestamp-based navigation
- **⏰ Interactive Timeline**: Click timestamps to jump to specific video segments
- **🎨 Modern UI**: Clean, responsive interface built with Streamlit

## 🛠️ Installation

### Prerequisites
- Python 3.8 or higher
- Google AI API key

### Setup Steps

1. **Clone or download the project**
   ```bash
   # If you have the project folder, navigate to it
   cd 5056597-Summarizer_SK
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up your Google AI API key**
   - Get your API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
   - You can enter it in the app sidebar or set as environment variable:
   ```bash
   export GOOGLE_API_KEY="your-api-key-here"
   ```

## 🚀 Running the Application

```bash
streamlit run app.py
```

The application will open in your web browser at `http://localhost:8501`

## 📖 How to Use

1. **Enter API Key**: Input your Google AI API key in the sidebar
2. **Paste YouTube URL**: Enter any YouTube video URL
3. **Click Analyze**: Wait for the AI to process the video
4. **Explore Results**: Navigate through different tabs to view:
   - **Summary**: Quick overview of the video content
   - **Article**: Detailed, well-structured article format
   - **Key Points**: Bullet-point list of main concepts
   - **Q&A**: Generated questions and answers
   - **Timestamps**: Interactive timeline with video segments

## 🏗️ Architecture

### Core Components

- **Transcript Extraction**: Uses `youtube-transcript-api` and `langchain-community`
- **Text Processing**: Implements chunking for long transcripts
- **AI Processing**: Leverages OpenAI models via LangChain
- **Web Interface**: Built with Streamlit for interactive user experience

### Key Features

- **Smart Chunking**: Automatically splits long transcripts for optimal processing
- **Multiple Chains**: Separate AI chains for different output formats
- **Error Handling**: Comprehensive error handling for invalid URLs or API issues
- **Responsive Design**: Works on desktop and mobile devices

## 🔧 Configuration

### Model Selection
Choose between:
- `gemini-2.5-flash` (latest, highest quality, faster processing)
- `gemini-2.5-flash-lite` (latest, cost-effective, good quality)

### Processing Options
The app automatically:
- Handles transcripts up to 20,000+ words
- Splits long content into manageable chunks
- Preserves context across chunks
- Filters out filler content and marketing language

## 📝 Example Use Cases

- **Education**: Transform lecture videos into study notes
- **Content Creation**: Repurpose video content for blog posts
- **Research**: Quickly analyze technical presentations
- **Learning**: Generate Q&A pairs for self-testing
- **Documentation**: Create written records from video tutorials

## 🐛 Troubleshooting

### Common Issues

1. **"Invalid YouTube URL"**
   - Ensure the URL is complete and correct
   - Check that the video is public and has subtitles

2. **"Could not extract transcript"**
   - The video might not have subtitles
   - Try a different video or check if subtitles are available

3. **API Key Issues**
   - Verify your OpenAI API key is valid
   - Check if you have sufficient credits

4. **Long Processing Times**
   - Longer videos take more time to process
   - Consider using shorter videos for testing

## 🤝 Contributing

Feel free to enhance the application with:
- Additional output formats
- Support for more video platforms
- Advanced timestamp extraction
- Custom styling options
- Export functionality (PDF, Markdown)

## 📄 License

This project is for educational and demonstration purposes. Please ensure compliance with YouTube's terms of service and Google AI's usage policies.

## 🔗 Dependencies

- [Streamlit](https://streamlit.io/) - Web app framework
- [LangChain](https://www.langchain.com/) - AI framework
- [Google AI](https://ai.google.dev/) - AI model provider
- [YouTube Transcript API](https://github.com/jdepoix/youtube-transcript-api) - Transcript extraction

---

**Built with ❤️ using Streamlit and AI**
