import streamlit as st
import os
import re
import time
from typing import Dict, List, Tuple
import json

# LangChain imports
from langchain_community.document_loaders import YoutubeLoader
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

# Additional imports for direct transcript extraction
try:
    from youtube_transcript_api import YouTubeTranscriptApi
    from urllib.parse import urlparse, parse_qs
    YOUTUBE_TRANSCRIPT_AVAILABLE = True
except ImportError:
    YOUTUBE_TRANSCRIPT_AVAILABLE = False

# Set page config
st.set_page_config(
    page_title="YouTube Video Summarizer",
    page_icon="📹",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2c3e50;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .timestamp-link {
        color: #e74c3c;
        text-decoration: none;
        font-weight: bold;
    }
    .timestamp-link:hover {
        text-decoration: underline;
    }
    .key-point {
        background-color: #f8f9fa;
        padding: 1rem;
        border-left: 4px solid #3498db;
        margin: 0.5rem 0;
        border-radius: 4px;
    }
    .qa-pair {
        background-color: #fff3cd;
        padding: 1rem;
        margin: 1rem 0;
        border-radius: 8px;
        border: 1px solid #ffeaa7;
    }
    .summary-box {
        background-color: #e8f5e8;
        padding: 1.5rem;
        border-radius: 8px;
        border-left: 4px solid #27ae60;
        margin: 1rem 0;
    }
    .article-box {
        background-color: #f0f8ff;
        padding: 1.5rem;
        border-radius: 8px;
        border-left: 4px solid #3498db;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state variables
if 'transcript' not in st.session_state:
    st.session_state.transcript = ""
if 'summary' not in st.session_state:
    st.session_state.summary = ""
if 'article' not in st.session_state:
    st.session_state.article = ""
if 'key_points' not in st.session_state:
    st.session_state.key_points = []
if 'qa_pairs' not in st.session_state:
    st.session_state.qa_pairs = []
if 'timestamps' not in st.session_state:
    st.session_state.timestamps = []
if 'processing' not in st.session_state:
    st.session_state.processing = False
if 'video_info' not in st.session_state:
    st.session_state.video_info = {}

def extract_video_id(url: str) -> str:
    """Extract video ID from YouTube URL using modern approach"""
    # Clean URL by removing tracking parameters
    url = url.split('&')[0]
    
    try:
        parsed = urlparse(url)
        
        if parsed.hostname == "youtu.be":
            return parsed.path[1:]  # Remove leading slash
        
        if parsed.hostname in ["www.youtube.com", "youtube.com", "m.youtube.com"]:
            return parse_qs(parsed.query)['v'][0]
            
    except (KeyError, IndexError):
        pass
    
    # Fallback to regex patterns
    patterns = [
        r'(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([a-zA-Z0-9_-]{11})',
        r'youtube\.com/watch\?.*v=([a-zA-Z0-9_-]{11})'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return None

def get_transcript_with_timestamps(youtube_url: str) -> Tuple[str, List[Dict]]:
    """Extract transcript with timestamps using modern approach"""
    video_id = extract_video_id(youtube_url)
    
    if not video_id:
        st.error("Could not extract video ID from URL")
        return None, [], {}
    
    # Use modern youtube-transcript-api approach
    if YOUTUBE_TRANSCRIPT_AVAILABLE:
        try:
            st.info("Extracting transcript using YouTube Transcript API...")
            api = YouTubeTranscriptApi()
            transcript = api.fetch(video_id)
            
            if transcript:
                # Combine transcript text
                transcript_text = " ".join([chunk.text for chunk in transcript])
                
                # Create timestamps from transcript data
                timestamps = []
                for chunk in transcript[:20]:  # Limit to first 20 timestamps
                    minutes = chunk.start // 60
                    seconds = chunk.start % 60
                    timestamps.append({
                        "time": f"{int(minutes):02d}:{int(seconds):02d}",
                        "seconds": int(chunk.start),
                        "text": chunk.text[:100] + "..." if len(chunk.text) > 100 else chunk.text
                    })
                
                # Get basic video info
                video_info = {
                    'video_id': video_id,
                    'title': 'YouTube Video',
                    'author': 'Unknown Channel'
                }
                
                return transcript_text, timestamps, video_info
            else:
                st.error("No transcript available for this video")
                return None, [], {}
                
        except Exception as e:
            st.warning(f"YouTube Transcript API failed: {str(e)}")
            st.info("This could happen if:")
            st.info("• The video doesn't have subtitles/captions")
            st.info("• The video is private or restricted")
            st.info("• The video is region-restricted")
            st.info("• YouTube is blocking requests")
            return None, [], {}
    
    # Fallback if youtube-transcript-api not available
    st.error("YouTube Transcript API not available")
    return None, [], {}

def extract_timestamps_from_transcript(transcript: str) -> List[Dict]:
    """Extract timestamps from transcript text"""
    # This is a simplified approach - you might want to enhance this
    # with actual timestamp parsing from the YouTube API
    timestamps = []
    lines = transcript.split('\n')
    
    for i, line in enumerate(lines):
        if line.strip():
            # Estimate timestamp based on character position (rough approximation)
            estimated_time = int((i / len(lines)) * 300)  # Assume 5 minutes total
            timestamps.append({
                "time": format_time(estimated_time),
                "seconds": estimated_time,
                "text": line.strip()[:100] + "..." if len(line.strip()) > 100 else line.strip()
            })
    
    return timestamps[:20]  # Limit to first 20 timestamps

def format_time(seconds: int) -> str:
    """Format seconds as MM:SS"""
    minutes = seconds // 60
    secs = seconds % 60
    return f"{minutes:02d}:{secs:02d}"

def chunk_text(text: str, chunk_size: int = 4000, chunk_overlap: int = 200) -> List[str]:
    """Split text into chunks for processing"""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    return splitter.split_text(text)

def initialize_llm(model_name="gemini-2.5-flash"):
    """Initialize the LLM"""
    api_key = "AIzaSyA-D8yZvUS3UpxkzOpiDzssIhm9pca73qY"
    
    return ChatGoogleGenerativeAI(
        model=model_name,
        temperature=0.3,
        google_api_key=api_key
    )

def create_summary_chain(llm):
    """Create chain for generating summary"""
    system_message = """You are an expert content summarizer. Create concise, informative summaries that capture the main ideas and key insights from YouTube video transcripts."""
    
    human_message = """
    Create a comprehensive summary of the following YouTube video transcript:
    
    {transcript}
    
    Your summary should:
    - Be 3-5 paragraphs long
    - Capture the main topic and key points
    - Highlight important insights or conclusions
    - Be written in a clear, engaging style
    """
    
    prompt = ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(system_message),
        HumanMessagePromptTemplate.from_template(human_message)
    ])
    
    return prompt | llm | StrOutputParser()

def create_article_chain(llm):
    """Create chain for generating detailed article"""
    system_message = """You are a professional article writer for tech blogs and educational platforms. Transform video transcripts into well-structured, engaging articles."""
    
    human_message = """
    Transform the following YouTube transcript into a detailed, professional article:
    
    {transcript}
    
    The article should:
    - Have a compelling title and introduction
    - Use clear headings and subheadings
    - Include bullet points for key concepts
    - Maintain a professional yet engaging tone
    - Be comprehensive and well-structured
    - Ignore filler words, "um", "uh", and repetitive phrases
    - Focus on the actual content and insights
    """
    
    prompt = ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(system_message),
        HumanMessagePromptTemplate.from_template(human_message)
    ])
    
    return prompt | llm | StrOutputParser()

def create_key_points_chain(llm):
    """Create chain for extracting key points"""
    system_message = """You are an expert at identifying and extracting key information from educational content."""
    
    human_message = """
    Extract the most important key points from this YouTube transcript:
    
    {transcript}
    
    Return as a numbered list of 5-7 key points. Each point should:
    - Be a complete, clear sentence
    - Represent a significant concept or insight
    - Be actionable or informative
    """
    
    prompt = ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(system_message),
        HumanMessagePromptTemplate.from_template(human_message)
    ])
    
    return prompt | llm | StrOutputParser()

def create_qa_chain(llm):
    """Create chain for generating Q&A pairs"""
    system_message = """You are an educational content expert who creates insightful questions and answers based on video content."""
    
    human_message = """
    Based on this YouTube transcript, create 5-7 question and answer pairs that:
    
    {transcript}
    
    Each Q&A pair should:
    - Address important concepts from the video
    - Have clear, concise questions
    - Provide accurate, informative answers
    - Help viewers understand the content better
    
    Format each pair as:
    Q: [Question]
    A: [Answer]
    """
    
    prompt = ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(system_message),
        HumanMessagePromptTemplate.from_template(human_message)
    ])
    
    return prompt | llm | StrOutputParser()

def process_transcript(transcript: str, llm) -> Dict:
    """Process transcript to generate all outputs"""
    results = {}
    
    # Create chains
    summary_chain = create_summary_chain(llm)
    article_chain = create_article_chain(llm)
    key_points_chain = create_key_points_chain(llm)
    qa_chain = create_qa_chain(llm)
    
    # For long transcripts, process in chunks
    if len(transcript) > 8000:
        chunks = chunk_text(transcript)
        processed_chunks = []
        
        for chunk in chunks:
            processed_chunks.append(chunk)
        
        # Use first few chunks for processing (to manage token limits)
        processing_text = " ".join(chunks[:3])
    else:
        processing_text = transcript
    
    # Generate all outputs
    with st.spinner("Generating summary..."):
        results['summary'] = summary_chain.invoke({"transcript": processing_text})
    
    with st.spinner("Creating detailed article..."):
        results['article'] = article_chain.invoke({"transcript": processing_text})
    
    with st.spinner("Extracting key points..."):
        results['key_points'] = key_points_chain.invoke({"transcript": processing_text})
    
    with st.spinner("Generating Q&A pairs..."):
        results['qa_pairs'] = qa_chain.invoke({"transcript": processing_text})
    
    return results

def parse_key_points(key_points_text: str) -> List[str]:
    """Parse key points from generated text"""
    lines = key_points_text.split('\n')
    points = []
    
    for line in lines:
        line = line.strip()
        if line and (line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.')) or 
                     line.startswith(('-', '•', '*'))):
            points.append(line)
    
    return points

def parse_qa_pairs(qa_text: str) -> List[Dict]:
    """Parse Q&A pairs from generated text"""
    lines = qa_text.split('\n')
    pairs = []
    current_q = ""
    current_a = ""
    
    for line in lines:
        line = line.strip()
        if line.startswith('Q:'):
            if current_q and current_a:
                pairs.append({"question": current_q, "answer": current_a})
            current_q = line[2:].strip()
            current_a = ""
        elif line.startswith('A:'):
            current_a = line[2:].strip()
        elif current_a and line:  # Continuation of answer
            current_a += " " + line
    
    if current_q and current_a:
        pairs.append({"question": current_q, "answer": current_a})
    
    return pairs

def main():
    # Header
    st.markdown('<h1 class="main-header">📹 YouTube Video Summarizer</h1>', unsafe_allow_html=True)
    
    # Sidebar for settings
    with st.sidebar:
        st.header("⚙️ Settings")
        
        # Model selection
        model_option = st.selectbox(
            "Select Model",
            ["gemini-2.5-flash", "gemini-2.5-flash-lite"],
            help="Choose the AI model for processing"
        )
        
        st.markdown("---")
        
        # Instructions
        st.markdown("### 📖 How to Use")
        st.markdown("""
        1. Paste a YouTube video URL
        2. Select AI model
        3. Click 'Analyze Video'
        4. Explore the generated content
        """)
        
        st.markdown("---")
        st.info("✅ API Key is pre-configured")
    
    # Main content area
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown('<h2 class="section-header">🎥 Video Input</h2>', unsafe_allow_html=True)
        
        # URL input
        youtube_url = st.text_input(
            "YouTube Video URL",
            placeholder="https://www.youtube.com/watch?v=...",
            help="Enter the full YouTube video URL"
        )
        
        # Example URLs
        with st.expander("📝 Example URLs"):
            st.markdown("""
            - https://www.youtube.com/watch?v=-46UkLPf9h0
            - https://www.youtube.com/watch?v=dQw4w9WgXcQ
            - https://youtu.be/3JZ_D3ELwOQ
            """)
        
        # Process button
        process_button = st.button(
            "🚀 Analyze Video",
            type="primary",
            disabled=not youtube_url
        )
        
        # Video info display
        if st.session_state.video_info:
            st.markdown("### 📊 Video Information")
            if 'title' in st.session_state.video_info:
                st.write(f"**Title:** {st.session_state.video_info['title']}")
            if 'author' in st.session_state.video_info:
                st.write(f"**Channel:** {st.session_state.video_info['author']}")
            if 'length' in st.session_state.video_info:
                st.write(f"**Duration:** {st.session_state.video_info['length']}")
    
    with col2:
        if process_button and youtube_url:
            st.session_state.processing = True
            
            # Extract video ID
            video_id = extract_video_id(youtube_url)
            if not video_id:
                st.error("Invalid YouTube URL. Please check and try again.")
                st.session_state.processing = False
                return
            
            # Initialize LLM
            llm = initialize_llm(model_option)
            if not llm:
                st.session_state.processing = False
                return
            
            # Extract transcript
            with st.spinner("📥 Extracting transcript..."):
                transcript, timestamps, video_info = get_transcript_with_timestamps(youtube_url)
                
                if not transcript:
                    st.error("Could not extract transcript. The video might not have subtitles or might be private.")
                    st.session_state.processing = False
                    return
                
                st.session_state.transcript = transcript
                st.session_state.timestamps = timestamps
                st.session_state.video_info = video_info
            
            # Process transcript
            results = process_transcript(transcript, llm)
            
            st.session_state.summary = results.get('summary', '')
            st.session_state.article = results.get('article', '')
            st.session_state.key_points = parse_key_points(results.get('key_points', ''))
            st.session_state.qa_pairs = parse_qa_pairs(results.get('qa_pairs', ''))
            
            st.session_state.processing = False
            st.success("✅ Video analysis complete!")
        
        # Display results
        if st.session_state.summary:
            st.markdown('<h2 class="section-header">📝 Analysis Results</h2>', unsafe_allow_html=True)
            
            # Tabs for different outputs
            tab1, tab2, tab3, tab4, tab5 = st.tabs([
                "📄 Summary", 
                "📖 Article", 
                "🔑 Key Points", 
                "❓ Q&A", 
                "⏰ Timestamps"
            ])
            
            with tab1:
                st.markdown('<div class="summary-box">', unsafe_allow_html=True)
                st.markdown("### 📄 Executive Summary")
                st.write(st.session_state.summary)
                st.markdown('</div>', unsafe_allow_html=True)
            
            with tab2:
                st.markdown('<div class="article-box">', unsafe_allow_html=True)
                st.markdown("### 📖 Detailed Article")
                st.write(st.session_state.article)
                st.markdown('</div>', unsafe_allow_html=True)
            
            with tab3:
                st.markdown("### 🔑 Key Points")
                for i, point in enumerate(st.session_state.key_points, 1):
                    st.markdown(f'<div class="key-point">{i}. {point}</div>', unsafe_allow_html=True)
            
            with tab4:
                st.markdown("### ❓ Questions & Answers")
                for i, pair in enumerate(st.session_state.qa_pairs, 1):
                    st.markdown(f'<div class="qa-pair">', unsafe_allow_html=True)
                    st.markdown(f"**Q{i}:** {pair['question']}")
                    st.markdown(f"**A{i}:** {pair['answer']}")
                    st.markdown('</div>', unsafe_allow_html=True)
            
            with tab5:
                st.markdown("### ⏰ Video Timeline")
                if st.session_state.timestamps:
                    for ts in st.session_state.timestamps:
                        video_url_with_time = f"{youtube_url}&t={ts['seconds']}"
                        st.markdown(
                            f'<a href="{video_url_with_time}" target="_blank" class="timestamp-link">'
                            f'{ts["time"]}</a>: {ts["text"]}',
                            unsafe_allow_html=True
                        )
                else:
                    st.info("Timestamps not available for this video.")
        
        # Processing indicator
        if st.session_state.processing:
            st.info("🔄 Processing video... This may take a few moments.")
    
    # Footer
    st.markdown("---")
    st.markdown(
        '<div style="text-align: center; color: #666;">'
        'YouTube Video Summarizer • Powered by AI • Built with Streamlit'
        '</div>',
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
